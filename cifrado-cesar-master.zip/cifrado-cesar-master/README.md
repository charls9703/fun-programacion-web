# Cifrado César implementado en JS

[Demo en vivo](https://utn-mdp.github.io/cifrado-cesar/)

### Para iniciarlo:

```bash
# clonen el proyecto:
git clone https://github.com/UTN-MDP/cifrado-cesar.git

# entren en la carpeta
cd cifrado-cesar

# inicien un servidor web
php -S localhost:8888

# si no tienen PHP instalado, abran el archivo index.html directamente en el navegador.
```

> Revisar los issues abiertos e intentar solucionarlos
